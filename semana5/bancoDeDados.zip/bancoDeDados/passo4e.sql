delete from CarteirasEstudantis
where ce_instituicao = "UFRN" 
or ce_nivelensino = "Técnico";