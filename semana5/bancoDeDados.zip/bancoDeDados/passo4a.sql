select *
from CarteirasEstudantis;