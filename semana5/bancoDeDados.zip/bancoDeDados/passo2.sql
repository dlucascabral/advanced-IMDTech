create table CarteirasEstudantis(
	ce_matricula varchar(11),
    ce_instituicao varchar(50),
    ce_nivelensino varchar(15),
    ce_estudantenome varchar(50),
    ce_datanascimento date
);