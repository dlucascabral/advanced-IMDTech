create database sistemaestudantil;
use sistemaestudantil;
