select *
from CarteirasEstudantis
where ce_datanascimento < "1900-01-01";