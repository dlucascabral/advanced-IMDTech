select *
from CarteirasEstudantis
where ce_nivelensino = "Técnico";