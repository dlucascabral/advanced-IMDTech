insert into CarteirasEstudantis(ce_matricula, ce_instituicao, ce_nivelensino, ce_estudantenome, ce_datanascimento)
	values
		("20192151084", "UFRN", "Superior", "Maria Curie", "1867-11-07"),
		("20182109700", "IMD", "Técnico", "Ada Lovelace", "1815-12-10"),
		("20207698054", "UFERSA", "Superior", "Rita Levi-Montalcini", "1909-04-22"),
		("20202151097", "UERN", "Técnico", "Rachel Carson", "1907-05-27");