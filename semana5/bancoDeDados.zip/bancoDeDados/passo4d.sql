update CarteirasEstudantis
set CarteirasEstudantis.ce_nivelensino = "Superior"
where CarteirasEstudantis.ce_instituicao = "UERN";